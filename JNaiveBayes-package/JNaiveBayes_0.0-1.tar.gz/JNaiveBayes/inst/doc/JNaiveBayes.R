### R code from vignette source 'JNaiveBayes.Rnw'

###################################################
### code chunk number 1: JNaiveBayes.Rnw:86-94
###################################################
library(JNaiveBayes)
library(xtable)
train <- system.file("Data", "Training", package = "JNaiveBayes")
test <- system.file("Data", "Testing", package = "JNaiveBayes")
model1 <- JNaiveBayes(trainDir = train, testDir = test, parametric = FALSE, delta = 0.01)
model2 <- JNaiveBayes(trainDir = train, testDir = test, parametric = TRUE, delta = 0.01)
model3 <- JNaiveBayes(trainDir = train, testDir = test, parametric = FALSE, delta = 0.15)
xtable(model1$Probabilities);xtable(model2$Probabilities);


